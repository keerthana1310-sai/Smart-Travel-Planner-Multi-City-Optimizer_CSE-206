document.addEventListener('DOMContentLoaded', () => {
    const MAX_CITIES = 10;
    
    // DOM Elements
    const citiesList = document.getElementById('cities-list');
    const btnAddCity = document.getElementById('btn-add-city');
    const cityCountWarning = document.getElementById('city-count-warning');
    const startCitySelect = document.getElementById('start-city-idx');
    const costMatrixTable = document.getElementById('cost-matrix-table');
    const timeMatrixTable = document.getElementById('time-matrix-table');
    
    const inputBudget = document.getElementById('budget');
    const inputTime = document.getElementById('max-time');
    const budgetSlider = document.getElementById('budget-slider');
    const budgetVal = document.getElementById('budget-val');
    const timeSlider = document.getElementById('time-slider');
    const timeVal = document.getElementById('time-val');
    
    const btnGenerate = document.getElementById('btn-generate');
    const btnOptimize = document.getElementById('btn-optimize');
    const btnRecompute = document.getElementById('btn-recompute');
    const resultsSection = document.getElementById('results-section');
    const loader = document.getElementById('loader');

    // State
    let cities = [];

    // Initialize with 5 default cities
    const defaultCities = ["New York", "London", "Paris", "Tokyo", "Sydney"];
    defaultCities.forEach(name => addCity(name));

    // Sliders
    budgetSlider.addEventListener('input', (e) => {
        budgetVal.textContent = e.target.value;
        inputBudget.value = e.target.value;
    });

    timeSlider.addEventListener('input', (e) => {
        timeVal.textContent = e.target.value;
        inputTime.value = e.target.value;
    });

    inputBudget.addEventListener('input', (e) => {
        budgetSlider.value = e.target.value;
        budgetVal.textContent = e.target.value;
    });

    inputTime.addEventListener('input', (e) => {
        timeSlider.value = e.target.value;
        timeVal.textContent = e.target.value;
    });

    // Add City
    btnAddCity.addEventListener('click', () => {
        addCity(`City ${cities.length + 1}`);
    });

    function addCity(name) {
        if (cities.length >= MAX_CITIES) return;

        const cityId = `city-${Date.now()}`;
        const index = cities.length;
        
        cities.push({ id: cityId, name: name });

        renderCities();
        renderMatrices();
        updateStartCitySelect();
    }

    function removeCity(index) {
        if (cities.length <= 2) {
            alert("You need at least 2 cities.");
            return;
        }
        cities.splice(index, 1);
        renderCities();
        renderMatrices();
        updateStartCitySelect();
    }

    function renderCities() {
        citiesList.innerHTML = '';
        cities.forEach((city, index) => {
            const card = document.createElement('div');
            card.className = 'city-input-card';
            card.innerHTML = `
                <div class="city-header">
                    <span>City ${index + 1}</span>
                    <button class="btn-remove-city" title="Remove" onclick="window.removeCity(${index})">×</button>
                </div>
                <div class="form-group" style="margin-bottom:0">
                    <input type="text" value="${city.name}" onchange="window.updateCityName(${index}, this.value)" placeholder="City Name">
                </div>
            `;
            citiesList.appendChild(card);
        });

        if (cities.length >= MAX_CITIES) {
            btnAddCity.disabled = true;
            cityCountWarning.classList.remove('hidden');
        } else {
            btnAddCity.disabled = false;
            cityCountWarning.classList.add('hidden');
        }
    }

    // Global exposes for inline handlers
    window.removeCity = removeCity;
    window.updateCityName = (index, val) => {
        cities[index].name = val;
        updateStartCitySelect();
        renderMatrices(); // Update table headers
    };

    function updateStartCitySelect() {
        const currentVal = startCitySelect.value;
        startCitySelect.innerHTML = '';
        cities.forEach((city, index) => {
            const option = document.createElement('option');
            option.value = index;
            option.textContent = city.name;
            startCitySelect.appendChild(option);
        });
        if (currentVal && currentVal < cities.length) {
            startCitySelect.value = currentVal;
        }
    }

    function renderMatrices() {
        const n = cities.length;
        
        // Render Cost
        let costHTML = `<tr><th></th>${cities.map(c => `<th>${c.name}</th>`).join('')}</tr>`;
        for (let i = 0; i < n; i++) {
            costHTML += `<tr><th>${cities[i].name}</th>`;
            for (let j = 0; j < n; j++) {
                const disabled = (i === j) ? 'disabled' : '';
                const val = (i === j) ? 0 : 50;
                costHTML += `<td><input type="number" id="cost-${i}-${j}" class="matrix-input" value="${val}" min="0" ${disabled}></td>`;
            }
            costHTML += `</tr>`;
        }
        costMatrixTable.innerHTML = costHTML;

        // Render Time
        let timeHTML = `<tr><th></th>${cities.map(c => `<th>${c.name}</th>`).join('')}</tr>`;
        for (let i = 0; i < n; i++) {
            timeHTML += `<tr><th>${cities[i].name}</th>`;
            for (let j = 0; j < n; j++) {
                const disabled = (i === j) ? 'disabled' : '';
                const val = (i === j) ? 0 : 5;
                timeHTML += `<td><input type="number" id="time-${i}-${j}" class="matrix-input" value="${val}" min="0" ${disabled}></td>`;
            }
            timeHTML += `</tr>`;
        }
        timeMatrixTable.innerHTML = timeHTML;
    }

    // Fill Random Data
    btnGenerate.addEventListener('click', () => {
        const n = cities.length;
        
        for (let i = 0; i < n; i++) {
            for (let j = 0; j < n; j++) {
                if (i !== j) {
                    const costInput = document.getElementById(`cost-${i}-${j}`);
                    const timeInput = document.getElementById(`time-${i}-${j}`);
                    if (costInput) costInput.value = Math.floor(Math.random() * 150) + 20;
                    if (timeInput) timeInput.value = Math.floor(Math.random() * 15) + 2;
                }
            }
        }
        
        btnGenerate.textContent = "✅ Generated!";
        setTimeout(() => btnGenerate.textContent = "🎲 Fill Random Data", 2000);
    });

    const performOptimization = async () => {
        const budget = parseInt(inputBudget.value, 10);
        const maxTime = parseInt(inputTime.value, 10);
        const startCity = parseInt(startCitySelect.value, 10);
        const n = cities.length;

        const city_names = cities.map(c => c.name);
        
        const cost_matrix = [];
        const time_matrix = [];

        for (let i = 0; i < n; i++) {
            const crow = [];
            const trow = [];
            for (let j = 0; j < n; j++) {
                const cval = i === j ? 0 : parseInt(document.getElementById(`cost-${i}-${j}`).value, 10);
                const tval = i === j ? 0 : parseInt(document.getElementById(`time-${i}-${j}`).value, 10);
                crow.push(cval);
                trow.push(tval);
            }
            cost_matrix.push(crow);
            time_matrix.push(trow);
        }

        const payload = {
            num_cities: n,
            start_city: startCity,
            budget: budget,
            max_time: maxTime,
            city_names: city_names,
            cost_matrix: cost_matrix,
            time_matrix: time_matrix
        };

        loader.classList.remove('hidden');

        try {
            const response = await fetch('/api/optimize', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || 'Server error');
            }

            renderResults(result, budget, maxTime);
            resultsSection.classList.remove('hidden');
            resultsSection.scrollIntoView({ behavior: 'smooth' });
        } catch (error) {
            console.error(error);
            alert("Optimization Failed: " + error.message);
        } finally {
            loader.classList.add('hidden');
        }
    };

    btnOptimize.addEventListener('click', performOptimization);
    btnRecompute.addEventListener('click', performOptimization);

    function renderResults(data, maxBudget, maxTime) {
        const totalCities = cities.length;

        function updateCard(prefix, res) {
            document.getElementById(`${prefix}-route`).textContent = res.route.join(' ➔ ');
            
            // Percentages
            const budgetPctStr = maxBudget > 0 ? ((res.total_cost / maxBudget) * 100).toFixed(1) : 0;
            const timePctStr = maxTime > 0 ? ((res.total_time / maxTime) * 100).toFixed(1) : 0;

            // Text updates
            document.getElementById(`${prefix}-cities-text`).textContent = `${res.cities_visited} / ${totalCities}`;
            document.getElementById(`${prefix}-budget-text`).textContent = `$${res.total_cost} / $${maxBudget} (${budgetPctStr}%)`;
            document.getElementById(`${prefix}-time-text`).textContent = `${res.total_time}h / ${maxTime}h (${timePctStr}%)`;

            // Progress bar updates
            const citiesPct = totalCities > 0 ? (res.cities_visited / totalCities) * 100 : 0;
            const budgetPct = maxBudget > 0 ? (res.total_cost / maxBudget) * 100 : 0;
            const timePct = maxTime > 0 ? (res.total_time / maxTime) * 100 : 0;

            document.getElementById(`${prefix}-cities-bar`).style.width = `${Math.min(citiesPct, 100)}%`;
            document.getElementById(`${prefix}-budget-bar`).style.width = `${Math.min(budgetPct, 100)}%`;
            document.getElementById(`${prefix}-time-bar`).style.width = `${Math.min(timePct, 100)}%`;
        }

        updateCard('greedy', data.greedy);
        updateCard('dp', data.dp);
    }
});

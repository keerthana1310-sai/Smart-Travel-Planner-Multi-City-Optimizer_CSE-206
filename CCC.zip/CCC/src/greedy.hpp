#ifndef GREEDY_HPP
#define GREEDY_HPP

#include <vector>
#include <string>
#include "json.hpp"

using json = nlohmann::json;

json run_greedy(int num_cities, int start_city, int budget, int max_time,
                const std::vector<std::string>& city_names,
                const std::vector<std::vector<int>>& cost_matrix,
                const std::vector<std::vector<int>>& time_matrix);

#endif

#include "greedy.hpp"
#include <vector>
#include <string>

using namespace std;

json run_greedy(int num_cities, int start_city, int budget, int max_time,
                const vector<string>& city_names,
                const vector<vector<int>>& cost_matrix,
                const vector<vector<int>>& time_matrix) {
    
    vector<string> route;
    int curr_city = start_city;
    int b = budget;
    int t = max_time;
    
    int total_cost = 0;
    int total_time = 0;
    
    vector<bool> visited(num_cities, false);
    visited[start_city] = true;
    route.push_back(city_names[start_city]);

    while (true) {
        int best_next = -1;
        int best_cost = 1e9;
        int best_time = 1e9;

        for (int nxt = 0; nxt < num_cities; nxt++) {
            if (!visited[nxt]) {
                int cost = cost_matrix[curr_city][nxt];
                int travel_time = time_matrix[curr_city][nxt];

                if (b >= cost && t >= travel_time) {
                    // Greedy heuristic: Pick the cheapest city to visit next.
                    // Tie-breaker: least time.
                    if (cost < best_cost) {
                        best_cost = cost;
                        best_time = travel_time;
                        best_next = nxt;
                    } else if (cost == best_cost && travel_time < best_time) {
                        best_time = travel_time;
                        best_next = nxt;
                    }
                }
            }
        }

        if (best_next == -1) {
            break; 
        }

        int cost = cost_matrix[curr_city][best_next];
        int travel_time = time_matrix[curr_city][best_next];

        route.push_back(city_names[best_next]);
        total_cost += cost;
        total_time += travel_time;

        b -= cost;
        t -= travel_time;
        visited[best_next] = true;
        curr_city = best_next;
    }

    return {
        {"route", route},
        {"total_cost", total_cost},
        {"total_time", total_time},
        {"cities_visited", (int)route.size()}
    };
}

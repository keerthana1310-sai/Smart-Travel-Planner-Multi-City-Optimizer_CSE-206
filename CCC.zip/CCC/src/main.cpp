#include <iostream>
#include <vector>
#include <string>
#include "json.hpp"
#include "greedy.hpp"
#include "dp.hpp"

using json = nlohmann::json;
using namespace std;

int main() {
    string input_str((istreambuf_iterator<char>(cin)), istreambuf_iterator<char>());
    
    if (input_str.empty()) {
        cerr << "Error: No input provided" << endl;
        return 1;
    }

    try {
        json input = json::parse(input_str);

        int num_cities = input["num_cities"];
        int start_city = input["start_city"];
        int budget = input["budget"];
        int max_time = input["max_time"];
        
        vector<string> city_names = input["city_names"].get<vector<string>>();
        vector<vector<int>> cost_matrix = input["cost_matrix"].get<vector<vector<int>>>();
        vector<vector<int>> time_matrix = input["time_matrix"].get<vector<vector<int>>>();

        json greedy_result = run_greedy(num_cities, start_city, budget, max_time, city_names, cost_matrix, time_matrix);
        json dp_result = run_dp(num_cities, start_city, budget, max_time, city_names, cost_matrix, time_matrix);

        json final_output = {
            {"greedy", greedy_result},
            {"dp", dp_result}
        };

        cout << final_output.dump() << endl;

    } catch (const std::exception& e) {
        cerr << "JSON Parsing or Execution Error: " << e.what() << endl;
        return 1;
    }

    return 0;
}
